// JS import all in JS
//import './send.js';
//import './send.js';

//import './jquery.fancybox.min.js';
//import './jquery-3.2.1.min.js';



import './common.js';
//import './compress.js';
